package com.scrolltest.apidemo.tests;

public class TestIntegration {

    // Create a new Person
    // Verify this person by making a Get Call
    // Update the name of person
    // Verify this person
    // Delete this person
    // Verify if deleted.
}
